
import streamlit as st

st.set_page_config(page_title="YouTube Insights Tool")

st.title("YouTube Insights Tool")
st.write("Upload your `client_secret.json` and enter a YouTube video URL to begin analysis.")
